extends KinematicBody2D

var left2
var right2
var jump2
var is_blasting2 = false
var blast2
var jab2
var is_jabbing2 = false
var health = 500
var block 
var is_blocking2 = false
var damage = 0
var is_hit = false
var hit_animationplaying = false


var myX2
var myY2

var speed2


func _ready():
	left2 = false
	right2 = false
	jump2 = false
	blast2 = false
	is_blasting2 = false
	jab2 = false
	is_jabbing2 = false
	is_blocking2 = false
	block = false
	
	myX2 = 0
	myY2 = 0
	
	speed2 = 200
	
	$Ken2.connect("animation_finished", self, "_on_animation_finished")
	$Ken2.frames.set_animation_loop("HADOUKEN", false)
	$Ken2.frames.set_animation_loop("jab", false)
	$Ken2.frames.set_animation_loop("down", false)
	$Ken2.frames.set_animation_loop("slight", false)

func _anim():
	if hit_animationplaying == true:
		return
	if is_blasting2 or is_jabbing2 == true:
		return
		
	if jab2 == true and  is_jabbing2 == false:
		is_jabbing2 = true 
		$Ken2.animation = "jab"
		$Ken2.play()
	elif blast2 == true and  is_blasting2 == false:
		is_blasting2 = true
		$Ken2.animation = "HADOUKEN"
		$Ken2.play()
	elif block == true:
		if  $Ken2.animation != "block" :
			$Ken2.animation = "block"
			$Ken2.play()
			is_blocking2 = true
	elif  is_blasting2 == false and is_jabbing2 == false:
		is_blocking2 = false
		if is_on_floor() == false:
			$Ken2.animation = "jump"
		elif right2 == true :
			$Ken2.animation = "walk"
		elif left2 == true :
			$Ken2.animation = "backwalk"
		elif jab2 and left2 == true :
			$Ken2.animation - "jab"
			$Ken2.flip_h = true
		elif jab2 and right2 == true :
			$Ken2.animation = "jab"
			$Ken2.flip_h = false
		else:
			$Ken2.animation = "default"
func _physics_process(delta):
	#print("Blast:", blast2)
	myY2 += 10 #gravity
	if is_blocking2 == true :
		myX2 = 0
	else :
		if left2 == true :
			myX2 = -speed2
		if right2 == true :
			myX2 = +speed2
		if right2 == left2 :
			myX2 = 0
	if is_on_floor() == true :
		myY2 = 1
		if jump2 == true :
			myY2 = -400
	_anim()
	
	
	move_and_slide(Vector2(myX2,myY2),Vector2(0,-1))

func _on_animation_finished():
	if $Ken2.animation == "HADOUKEN" :
		blast2 = false
		is_blasting2 = false
		print ("blast anim finished")
	elif $Ken2.animation == "jab" :
		jab2 = false
		is_jabbing2 = false
		print("jab anim finished")
	elif $Ken2.animation == "down" or $Ken2.animation == "slight":
		hit_animationplaying = false
		is_hit = false
		print("hit animation finished")
		$Ken2.animation = "default"
		$Ken2.play()
		if block == true :
			$Ken2.animation = "block"
			$Ken2.play()
		else :
			$Ken2.animation = "default"
			$Ken2.play()
func play_hit_animation(hit):
	if hit_animationplaying:
		return  
	if block == true  :
		return
	is_hit = true
	hit_animationplaying = true
	
	match hit:
		"down":
			$Ken2.animation = "down" 
		"slight":
			$Ken2.animation = "slight"
		"blockblast" :
			return
	$Ken2.play()

