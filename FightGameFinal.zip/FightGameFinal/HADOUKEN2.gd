extends RigidBody2D
var x = 0

func _ready():
	linear_velocity.x = -650
	linear_velocity.y = 0
	$Timer.start()

func _on_VisibilityNotifier2D_screen_exited():
	queue_free()


func _on_HADOUKEN2_body_entered(body):
	if body.name == "Player1" :
		get_parent() ._blastdmg2()
		print("PLAYER1 HIT")
		queue_free()


func _on_Timer_timeout():
	x+= 1
	if x == 2:
		queue_free()


