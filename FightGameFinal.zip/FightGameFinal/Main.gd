extends Node2D
var health = 500
var player2health = 500
var x = 0
var blastCD = true
var blastCD2 = true
var y = 0
var jabCD1_x = 0
var jabCD2_y = 0
var jabCD1 = false
var jabCD2 = false


onready var p1health = $P1Health/P1Health1
onready var p2health = $P2Health/P2Health1
func _ready():
	$MenuMusic.playing = true
	$Gameover.visible = false
	$JabTimer1.start()
	$JabTimer2.start()
	$Timer.start()
	$Timer2.start()
	$P1Health/P1Health1.max_value = 500
	$P1Health/P1Health1.value = health
	$P2Health/P2Health1.max_value = 500
	$P2Health/P2Health1.value = player2health
	$StartGame.visible = true
	$ScreenStart.visible = true
func _physics_process(delta):
	$Player1.left = Input.is_action_pressed("leftbutton")
	$Player1.right = Input.is_action_pressed("rightbutton")
	$Player1.jump = Input.is_action_pressed("jumpbutton")
	$Player1.jab = Input.is_action_just_pressed("jab1")
	$Player1.blast = Input.is_action_just_pressed("blast1")
	$Player1.block = Input.is_action_pressed("block")
	$Player2.left2 = Input.is_action_pressed("left")
	$Player2.right2 = Input.is_action_pressed("right")
	$Player2.jump2 = Input.is_action_pressed("jump")
	$Player2.jab2 = Input.is_action_just_pressed("jab2")
	$Player2.blast2 = Input.is_action_just_pressed("blast2")
	$Player2.block = Input.is_action_pressed("blockbutton")
	
	
	if $Player1.blast == true and blastCD == true  :
		print("Blast button  pressed")
		var scene = load ("HADOUKEN.tscn")
		var blast = scene.instance()
		print ("Player position", $Player1.position)
		blast.position = $Player1.position
		print("Blast position set to: ", blast.position)
		add_child(blast)
		print("Blast added as child")
		blastCD = false
		$Hadouken.playing = true
		print ("Cooldown time : " + str(x))
		x = 0
		$Timer.start()
		
	if $Player2.blast2 == true and blastCD2 == true  :
		print("Blast button  pressed")
		var scene2 = load ("HADOUKEN2.tscn")
		var blast2 = scene2.instance()
		print ("Player position", $Player2.position)
		blast2.position = $Player2.position
		print("Blast position set to: ", blast2.position)
		add_child(blast2)
		print("Blast added as child")
		blastCD2 = false
		$Hadouken.playing = true
		print ("Cooldown time : " + str(x))
		y = 0
		$Timer2.start()
		
	if $Player2.jab2 == true and jabCD2 == true:
		var scene2 = load ("Jab2.tscn")
		print("Jab button pressed")
		var jab2 = scene2.instance()
		jab2.position = $Player2.position
		jabCD2 = false
		add_child(jab2)
		$Punch.playing = true
		$JabTimer2.start()
	
	if $Player1.jab == true and jabCD1 == true :
		var scene = load ("Jab1.tscn")
		print("Jab button pressed")
		var jab1 = scene.instance()
		jab1.position = $Player1.position
		add_child(jab1)
		jabCD1 = false
		$Punch.playing = true
		$JabTimer1.start()
	
	
func update_health_bars():
	$P1Health/P1Health1.value = health
	$P2Health/P2Health1.value = player2health
func death():
	if health <=0 :
		print(" PLAYER 1 DEATH SEQUENCE")
		$Gameover.visible = true
		$KO.playing = true
		$GameMusic.playing = false
		$Death.playing = true
	if player2health <= 0 :
		print("PLAYER 2 DEATH SEQUENCE")
		$Gameover.visible = true
		$KO.playing = true
		$GameMusic.playing = false
		$Death.playing = true
	
func _blastdmg():
	var damage = 100
	if $Player2.block == true :
		damage = int(damage * .5)
		$BlockSound.playing = true
	$Player2.play_hit_animation("down")
	player2health -= damage
	update_health_bars()
	death()
	print ("Player 2 took blast damage Health: " + str(player2health))

func _blastdmg2():
	var damage = 100
	if $Player1.block == true :
		damage = int(damage * .5)
		$BlockSound.playing = true
	health -= damage
	update_health_bars()
	death()
	$Player1.play_hit_animation("down")
	print("Player 1 took blast damage Health: " + str(health))


func _jabdmg():
	var damage = 50
	if $Player2.block == true :
		damage = int(damage * .5)
		$Punch.playing = false
		$BlockSound.playing = true
	player2health -= damage
	update_health_bars()
	death()
	$Player2.play_hit_animation("slight")
	print("Player 2 took jab damage  Health: " + str(player2health))
	

func _jabdmg2():
	var damage = 50
	if $Player1.block == true :
		$Punch.playing = false
		$BlockSound.playing = true
		damage = int(damage * .5)
	health -= damage
	update_health_bars()
	death()
	$Player1.play_hit_animation("slight")
	print("Player 1 took jab damage Health: " + str(health))

func _on_Timer_timeout():
	x+=1 
	if x >8 :
		blastCD = true 
		
		$Timer.stop()

func _on_Timer2_timeout():
	y+=1 
	if y >8 :
		blastCD2 = true 

		$Timer2.stop()



func _on_JabTimer1_timeout():
	jabCD1_x += 1
	if jabCD1_x == 1 :
		jabCD1 = true 
		jabCD1_x = 0
		


func _on_JabTimer2_timeout():
	jabCD2_y += 1
	if jabCD2_y == 1:
		jabCD2 = true
		jabCD2_y = 0


func _on_StartGame_pressed():
	$ScreenStart.visible = false
	$StartGame.visible = false
	$MenuMusic.playing = false
	$GameMusic.playing = true
