extends KinematicBody2D

var left
var right
var jump
var is_blasting = false
var blast
var jab
var is_jabbing = false
var damage = 0
var health = 500
var block 
var is_blocking = false
var down 
var is_hit = false
var hit_animationplaying = false

var myX
var myY

var speed


func _ready():
	left = false
	right = false
	jump = false
	blast = false
	is_blasting = false
	jab = false
	is_jabbing = false
	block = false
	is_blocking = false
	down = false
	
	myX = 0
	myY = 0
	
	speed = 200
	
	$Ken.connect("animation_finished", self, "_on_animation_finished")
	$Ken.frames.set_animation_loop("HADOUKEN", false)
	$Ken.frames.set_animation_loop("jab", false)
	$Ken.frames.set_animation_loop("down", false)
	$Ken.frames.set_animation_loop("slight", false)
	$Ken.frames.set_animation_loop("block", true)

func _anim():
	if hit_animationplaying == true :
		return
	if is_blasting or is_jabbing == true:
		return
		
	if jab == true and  is_jabbing == false:
		is_jabbing = true 
		$Ken.animation = "jab"
		$Ken.play()
	elif blast == true and  is_blasting == false:
		is_blasting = true
		$Ken.animation = "HADOUKEN"
		$Ken.play()
	elif block == true:
		if $Ken.animation != "block" :
			$Ken.animation = "block"
			$Ken.play()
			is_blocking = true
	elif  is_blasting == false and is_jabbing == false:
		is_blocking = false
		if is_on_floor() == false:
			$Ken.animation = "jump"
		elif block == true :
			$Ken.animation = "block"
		elif right == true :
			$Ken.animation = "walk"
		elif left == true :
			$Ken.animation = "backwalk"
		elif jab and left == true :
			$Ken.animation - "jab"
			$Ken.flip_h = true
		elif jab and right == true :
			$Ken.animation = "jab"
			$Ken.flip_h == false
		else:
			$Ken.animation = "default"
func _physics_process(delta):
	#print("Blast:", blast)
	myY += 10 #gravity
	if is_blocking == true :
		myX = 0

	else :
		if left == true :
			myX = -speed
		if right == true :
			myX = +speed
		if right == left :
			myX = 0
	if is_on_floor() == true :
		myY = 1
		if jump == true :
			myY = -400
	_anim()
	
	
	move_and_slide(Vector2(myX,myY),Vector2(0,-1))

func _on_animation_finished():
	if $Ken.animation == "HADOUKEN" :
		blast = false
		is_blasting = false
		print ("blast anim finished")
	if $Ken.animation == "jab" :
		jab = false
		is_jabbing = false
		print("jab anim finished")
	elif $Ken.animation == "down" or $Ken.animation == "slight":
		hit_animationplaying = false
		is_hit = false
		print("hit animation finished")
		$Ken.animation = "default"
		$Ken.play()
		if block == true :
			$Ken.animation = "block"
			$Ken.play()
		else :
			$Ken.animation = "default"
			$Ken.play()
func play_hit_animation(hit):
	if hit_animationplaying:
		return  
	if block == true  :
		return
	is_hit = true
	hit_animationplaying = true
	
	
	match hit:
		"down":
			$Ken.animation = "down" 
		"slight":
			$Ken.animation = "slight"
		"blockblast":
			return
	$Ken.play()

