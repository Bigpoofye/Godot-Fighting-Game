extends RigidBody2D
var x = 1

func _ready():
	linear_velocity.x = 0
	linear_velocity.y = 0
	gravity_scale = 0
	$Timer.start()
	$Timer.wait_time = .3
func _on_Jab2_body_entered(body):
	if body.name == "Player1" :
		get_parent()._jabdmg2()
		print("PLAYER1 HIT BY PLAYER2")
		queue_free()



func _on_Timer_timeout():
	x += 1
	if x == 2 :
		queue_free()

