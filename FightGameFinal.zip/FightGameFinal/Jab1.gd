extends RigidBody2D
var x = 1

func _ready():
	linear_velocity.x = 0
	linear_velocity.y = 0
	gravity_scale = 0
	$Timer.start()
	$Timer.wait_time = .3
func _on_Jab1_body_entered(body):
	if body.name == "Player2" :
		get_parent() ._jabdmg()
		print("PLAYER2 HIT BY PLAYER1")
		queue_free()



func _on_Timer_timeout():
	x+= 1
	if x == 2:
		queue_free()

